import java.util.ArrayList;

public class SanduicheNatural extends Sanduiche {

	public SanduicheNatural() {
		name = "Sanduiche Natural"; 
		bread= "P�o de forma"; 
		sauce= "Maionese"; 
		toppings.add("Mu�arela");
		toppings.add("Salada");
		toppings.add("Peito de peru");
	}

}
