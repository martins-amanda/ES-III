
public class XTudo extends Sanduiche{

	public XTudo() {
		name = "X Tudo"; 
		bread= "P�o"; 
		sauce= "Maionese"; 
		toppings.add("Mu�arela");
		toppings.add("Salada");
		toppings.add("Bacon");
		toppings.add("Ovo frito");
		toppings.add("hamburger");
		
	}

}
