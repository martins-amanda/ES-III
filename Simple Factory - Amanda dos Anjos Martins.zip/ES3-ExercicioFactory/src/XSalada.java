
public class XSalada extends Sanduiche {

	public XSalada() {
		name = "X Salada"; 
		bread= "P�o"; 
		sauce= "Maionese"; 
		toppings.add("Mu�arela");
		toppings.add("Salada");
		toppings.add("Hamburger");
	}

}
