
public class XEgg extends Sanduiche{

	public XEgg() {
		name = "X Egg"; 
		bread= "P�o"; 
		sauce= "Maionese"; 
		toppings.add("Mu�arela");
		toppings.add("Salada");
		toppings.add("Ovo frito");
		toppings.add("hamburger");
	}

}
