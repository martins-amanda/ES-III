
public class XBacon extends Sanduiche{

	public XBacon() {
		name = "X Bacon"; 
		bread= "P�o"; 
		sauce= "Maionese"; 
		toppings.add("Mu�arela");
		toppings.add("Salada");
		toppings.add("Bacon");
		toppings.add("hamburger");
	}
	

}
